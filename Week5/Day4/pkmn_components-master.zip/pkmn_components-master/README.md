Pokemon Components
==================

An exercise in structuring your browser JavaScript in a Rails application.
